package lesson4.lab4C;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Main {
	public static void main(String[] args) {
		
		List<Order> list = new ArrayList<Order>();
		Order o1 = new Order(LocalDate.now(), 1500);
		list.add(o1);
		
		
		Employee[] employees = {
				new Salaried("123", 100000),
				new Hourly("123",50, 50),				
				new Commissioned("123",5,5000,list),
		};

		for (Employee e : employees) {
			System.out.println(e.calcCompensation(10, 2018).getNetPay());
		}
	}
}